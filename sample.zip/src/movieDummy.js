// src/movieDummy.js
export const dummy = [
  {
    id: 1,
    title: "분노의 질주: 라이드 오어 다이",
    rating: 7.3,
    poster_path: "/wXNihLltMCGR7XepN39syIlCt5X.jpg",
    overview: "A mind-bending thriller by Christopher Nolan."
  },
  {
    id: 2,
    title: "트랜스포머: 비스트의 서막",
    rating: 7.1,
    poster_path: "/chUZNPNd7EiETSB4xBGykXhuXRr.jpg",
    overview: "A journey beyond the stars to save humanity."
  }
];

export const img_base_url = "https://image.tmdb.org/t/p/w500";
