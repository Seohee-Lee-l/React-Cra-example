import React from "react";
import {useLocation, useNavigate} from "react-router-dom";
import {img_base_url} from "../movieDummy";
import "./MovieDetail.css";

function MovieDetail() {
    const location=useLocation();
    const navigate=useNavigate();
    const {title, poster_path, rating, overview}=location.state || {};

    if (!title) {
        return <p>영화를 찾을 수 없습니다.</p>
    }

    return (
        <div className="detail-container">
            <button className="back-btn" onClick={()=> navigate(-1)}>뒤로가기</button>

            <h1>{title}</h1>

            <img src={img_base_url+poster_path} alt={title} className="detail-img" />

            <p className="detail-rating">평점: {rating}</p>
            <p classNAme="detail-overview">{overview}</p>
        </div>
    );
}

export default MovieDetail;